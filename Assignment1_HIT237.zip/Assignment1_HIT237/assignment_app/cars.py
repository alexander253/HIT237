class Car:
    def __init__(self, id, name, origin, cylinders, model, year, s_package, desc, fact):
        self.id = id
        self.name = name
        self.origin= origin
        self.cylinders= cylinders
        self.model= model
        self.year=year
        self.s_package= s_package
        self.desc= desc
        self.fact= fact




    def __str__(self):
        return str(self.id) + ", " + self.name
