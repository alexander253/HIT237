from django.apps import AppConfig


class AssignmentAppConfig(AppConfig):
    name = 'assignment_app'
